package CT_03;

import CT_03.IndicatorSystem;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class IndicatorSystemTest {
    private IndicatorSystem system;

    @BeforeEach
    void setUp() {
        system = new IndicatorSystem();

        // Pré-condição: Indicadores cadastrados
        system.addIndicator("Taxa de Ocupação");
        system.addIndicator("Custo por Paciente");
        system.addIndicator("Taxa de Infecção Hospitalar");
    }

    @Test
    void testSearchByFullName() {
        // Cenário: Pesquisar pelo nome completo "Taxa de Ocupação"
        List<String> results = system.searchIndicators("Taxa de Ocupação");
        assertEquals(1, results.size(), "Deve retornar exatamente um indicador.");
        assertTrue(results.contains("Taxa de Ocupação"), "O indicador 'Taxa de Ocupação' deve estar nos resultados.");
    }

    @Test
    void testSearchByPartialName() {
        // Cenário: Pesquisar pelo termo parcial "Ocupação"
        List<String> results = system.searchIndicators("Ocupação");
        assertEquals(1, results.size(), "Deve retornar exatamente um indicador que contenha 'Ocupação'.");
        assertTrue(results.contains("Taxa de Ocupação"), "O indicador 'Taxa de Ocupação' deve estar nos resultados.");
    }

    @Test
    void testSearchNonexistentTerm() {
        // Cenário: Pesquisar por um termo que não existe "XYZ"
        List<String> results = system.searchIndicators("XYZ");
        assertTrue(results.isEmpty(), "Não deve retornar nenhum indicador para um termo inexistente.");
    }
}