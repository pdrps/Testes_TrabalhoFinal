package CT_07;

import java.util.HashMap;
import java.util.Map;

// Classe que simula o sistema de autenticação e gerenciamento de sessões
class UserSessionService {
    private final Map<String, String> registeredUsers = new HashMap<>();
    private String currentSessionUser = null;

    // Registra um novo usuário
    public void registerUser(String email, String password) {
        registeredUsers.put(email, password);
    }

    // Autentica o usuário
    public boolean login(String email, String password) {
        if (registeredUsers.containsKey(email) && registeredUsers.get(email).equals(password)) {
            currentSessionUser = email;
            return true;
        }
        return false;
    }

    // Realiza o logout do usuário
    public void logout() {
        currentSessionUser = null;
    }

    // Verifica se o usuário está autenticado
    public boolean isAuthenticated() {
        return currentSessionUser != null;
    }

    // Verifica o acesso a uma página protegida
    public String accessProtectedPage(String page) {
        if (isAuthenticated()) {
            return "Access granted to " + page;
        }
        return "Access denied. Redirecting to login page.";
    }
}
