package CT_07;

import static org.junit.jupiter.api.Assertions.*;

import CT_07.UserSessionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class UserSessionServiceTest {
    private UserSessionService sessionService;

    @BeforeEach
    void setUp() {
        sessionService = new UserSessionService();
        // Pré-condição: Registrar usuário
        sessionService.registerUser("user@example.com", "securePassword");
    }

    @Test
    void testLogoutSuccess() {
        // Cenário: Usuário autenticado realiza logout
        // Passo 1: Login com credenciais válidas
        assertTrue(sessionService.login("user@example.com", "securePassword"), "Usuário deve ser autenticado com sucesso.");

        // Passo 2: Logout
        sessionService.logout();

        // Passo 3: Verificar que o usuário foi deslogado
        assertFalse(sessionService.isAuthenticated(), "Usuário deve ser deslogado após o logout.");
    }

    @Test
    void testAccessProtectedPageAfterLogout() {
        // Cenário: Verificar acesso negado a páginas protegidas após logout
        // Passo 1: Login e logout
        sessionService.login("user@example.com", "securePassword");
        sessionService.logout();

        // Passo 2: Tentar acessar página protegida
        String result = sessionService.accessProtectedPage("Dashboard");
        assertEquals("Access denied. Redirecting to login page.", result, "Usuário deslogado não deve acessar páginas protegidas.");
    }

    @Test
    void testRedirectAfterLogout() {
        // Cenário: Verificar redirecionamento para login após logout
        // Passo 1: Login com credenciais válidas
        sessionService.login("user@example.com", "securePassword");

        // Passo 2: Logout
        sessionService.logout();

        // Passo 3: Tentar acessar outra página protegida
        String result = sessionService.accessProtectedPage("Settings");
        assertEquals("Access denied. Redirecting to login page.", result, "Usuário deslogado deve ser redirecionado à página de login.");
    }

    @Test
    void testAccessWithoutLogin() {
        // Cenário: Acesso a páginas protegidas sem autenticação
        // Passo 1: Tentar acessar uma página protegida sem autenticação
        String result = sessionService.accessProtectedPage("Profile");
        assertEquals("Access denied. Redirecting to login page.", result, "Sem autenticação, o acesso a páginas protegidas deve ser negado.");
    }
}
