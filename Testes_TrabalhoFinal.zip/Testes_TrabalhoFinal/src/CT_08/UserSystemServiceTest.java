package CT_08;

import static org.junit.jupiter.api.Assertions.*;

import CT_08.UserSystemService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class UserSystemServiceTest {
    private UserSystemService userService;

    @BeforeEach
    void setUp() {
        userService = new UserSystemService();
        // Pré-condição: Registrar usuários
        userService.registerUser("John Doe", "john.doe@example.com", "password123");
        userService.registerUser("Jane Smith", "jane.smith@example.com", "securePassword");
    }

    @Test
    void testDisplayUserInfoAfterLogin() {
        // Cenário: Exibir informações do usuário após login
        // Passo 1: Login com usuário válido
        boolean isLoggedIn = userService.login("john.doe@example.com", "password123");
        assertTrue(isLoggedIn, "O usuário deve ser autenticado com sucesso.");

        // Passo 2: Verificar informações exibidas
        String userInfo = userService.getLoggedUserInfo();
        assertEquals("Logged User: John Doe (john.doe@example.com)", userInfo,
                "As informações exibidas devem corresponder ao usuário logado.");
    }

    @Test
    void testDisplayUserInfoForDifferentUsers() {
        // Cenário: Exibir informações para diferentes usuários
        // Passo 1: Login com o primeiro usuário
        userService.login("john.doe@example.com", "password123");
        String userInfo1 = userService.getLoggedUserInfo();
        assertEquals("Logged User: John Doe (john.doe@example.com)", userInfo1);

        // Passo 2: Logout e login com outro usuário
        userService.logout();
        userService.login("jane.smith@example.com", "securePassword");
        String userInfo2 = userService.getLoggedUserInfo();
        assertEquals("Logged User: Jane Smith (jane.smith@example.com)", userInfo2,
                "As informações exibidas devem corresponder ao segundo usuário logado.");
    }

    @Test
    void testNoUserLoggedIn() {
        // Cenário: Exibir mensagem padrão quando nenhum usuário está logado
        String userInfo = userService.getLoggedUserInfo();
        assertEquals("No user logged in.", userInfo,
                "Quando nenhum usuário está logado, o sistema deve exibir uma mensagem padrão.");
    }

    @Test
    void testInvalidLogin() {
        // Cenário: Tentar login com credenciais inválidas
        boolean isLoggedIn = userService.login("invalid@example.com", "wrongPassword");
        assertFalse(isLoggedIn, "Usuários com credenciais inválidas não devem ser autenticados.");
    }
}
