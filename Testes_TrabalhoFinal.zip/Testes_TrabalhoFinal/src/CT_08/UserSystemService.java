package CT_08;

import java.util.HashMap;
import java.util.Map;

// Classe que simula o sistema de autenticação e exibição de informações do usuário
class UserSystemService {
    private final Map<String, User> registeredUsers = new HashMap<>();
    private User loggedUser = null;

    // Classe interna para representar um usuário
    static class User {
        String name;
        String email;
        String password;

        public User(String name, String email, String password) {
            this.name = name;
            this.email = email;
            this.password = password;
        }
    }

    // Registra um novo usuário
    public void registerUser(String name, String email, String password) {
        registeredUsers.put(email, new User(name, email, password));
    }

    // Autentica um usuário
    public boolean login(String email, String password) {
        User user = registeredUsers.get(email);
        if (user != null && user.password.equals(password)) {
            loggedUser = user;
            return true;
        }
        return false;
    }

    // Exibe informações do usuário autenticado
    public String getLoggedUserInfo() {
        if (loggedUser != null) {
            return "Logged User: " + loggedUser.name + " (" + loggedUser.email + ")";
        }
        return "No user logged in.";
    }

    // Realiza logout
    public void logout() {
        loggedUser = null;
    }
}
