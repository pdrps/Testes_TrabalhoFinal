package CT_06;

import CT_06.AuthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

// Classe de teste para validar o processo de autenticação
public class AuthServiceTest {
    private AuthService authService;

    @BeforeEach
    void setUp() {
        authService = new AuthService();

        // Pré-condição: Registrar usuários no sistema
        authService.registerUser("user1@example.com", "password123");
        authService.registerUser("user2@example.com", "securePass456");
    }

    @Test
    void testValidCredentials() {
        // Cenário: Credenciais válidas
        boolean isAuthenticated = authService.authenticate("user1@example.com", "password123");

        assertTrue(isAuthenticated, "O usuário deve ser autenticado com credenciais válidas.");
    }

    @Test
    void testInvalidPassword() {
        // Cenário: Senha inválida
        boolean isAuthenticated = authService.authenticate("user1@example.com", "wrongPassword");

        assertFalse(isAuthenticated, "O sistema deve rejeitar uma senha inválida.");
    }

    @Test
    void testInvalidEmail() {
        // Cenário: E-mail inválido
        boolean isAuthenticated = authService.authenticate("unknown@example.com", "password123");

        assertFalse(isAuthenticated, "O sistema deve rejeitar um e-mail não registrado.");
    }

    @Test
    void testInvalidEmailAndPassword() {
        // Cenário: E-mail e senha inválidos
        boolean isAuthenticated = authService.authenticate("unknown@example.com", "wrongPassword");

        assertFalse(isAuthenticated, "O sistema deve rejeitar credenciais completamente inválidas.");
    }

    @Test
    void testErrorMessageForInvalidCredentials() {
        // Cenário: Mensagem de erro para credenciais inválidas
        boolean isAuthenticated = authService.authenticate("user1@example.com", "wrongPassword");

        if (!isAuthenticated) {
            String errorMessage = "Credenciais inválidas";
            assertEquals("Credenciais inválidas", errorMessage, "A mensagem de erro deve ser exibida corretamente.");
        }
    }
}