package CT_04;

import CT_04.AlertSystem;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class AlertSystemTest {
    private AlertSystem system;

    @BeforeEach
    void setUp() {
        system = new AlertSystem();

        // Pré-condição: Configurar o limite crítico para 90%
        system.setCriticalLimit(90.0);
    }

    @Test
    void testNoAlertForBelowLimit() {
        // Cenário: Valor abaixo do limite (85%)
        system.evaluateIndicator("Taxa de Ocupação", 85.0);
        List<String> alerts = system.getAlertLog();

        assertTrue(alerts.isEmpty(), "Nenhum alerta deve ser gerado para valores abaixo do limite.");
    }

    @Test
    void testAlertForAboveLimit() {
        // Cenário: Valor acima do limite (95%)
        system.evaluateIndicator("Taxa de Ocupação", 95.0);
        List<String> alerts = system.getAlertLog();

        assertEquals(1, alerts.size(), "Deve haver exatamente um alerta gerado.");
        assertEquals("Alerta: Taxa de Ocupação crítica: 95.0%", alerts.get(0),
                "A mensagem de alerta deve ser precisa e conter os detalhes corretos.");
    }

    @Test
    void testMultipleEvaluations() {
        // Cenário: Valores múltiplos, apenas um acima do limite
        system.evaluateIndicator("Taxa de Ocupação", 85.0);
        system.evaluateIndicator("Taxa de Ocupação", 95.0);
        List<String> alerts = system.getAlertLog();

        assertEquals(1, alerts.size(), "Deve haver exatamente um alerta gerado para os valores avaliados.");
        assertEquals("Alerta: Taxa de Ocupação crítica: 95.0%", alerts.get(0),
                "A mensagem de alerta deve ser precisa e conter os detalhes corretos.");
    }
}